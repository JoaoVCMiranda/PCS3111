#include "Quarto.h"
#include "PersistenciaDeQuarto.h"

void teste1() {
  Quarto *q1= new Quarto(1,4);
  Quarto *q2= new Quarto(2,2);
  Quarto *q3= new Quarto(3,1);

  PersistenciaDeQuarto *pdq = new PersistenciaDeQuarto("teste1.txt"); 


  pdq->inserir(q1);
  pdq->inserir(q2); 
  pdq->inserir(q3);


  delete q1;
  delete q2;
  delete q3;
  delete pdq;
}

void teste2() {
  int quant = 5;
  string arquivo = "teste3.txt";
  PersistenciaDeQuarto *pdq = new PersistenciaDeQuarto(arquivo);
  Quarto **Q = nullptr;
  try{
    Quarto **Q = pdq->obter(quant);
    cout << Q <<endl;
    cout << quant << endl;


  }catch(exception *e){
    //debug
    cout<< e->what() << endl;
    delete e;
  }

  for(int i=0;i<quant;i++) if(Q[i] != nullptr) Q[i]->imprimir();

  for(int i =0;i<quant;i++) delete Q[i];

  delete pdq;
}
void teste3(){
  int quant = 5;
  string arquivo = "teste3.txt";
  PersistenciaDeQuarto *pdq = new PersistenciaDeQuarto(arquivo);
  Quarto **Q = nullptr;
  try{
    Quarto **Q = pdq->obter(quant);
    cout << Q <<endl;
    cout << quant << endl;


  }catch(exception *e){
    //debug
    cout<< e->what() << endl;
    delete e;
  }


}