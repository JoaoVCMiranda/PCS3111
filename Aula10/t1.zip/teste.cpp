#include "Quarto.h"
#include "PersistenciaDeQuarto.h"

void teste1() {
  Quarto *q1= new Quarto(1,4);
  Quarto *q2= new Quarto(2,2);
  Quarto *q3= new Quarto(3,1);

  PersistenciaDeQuarto *pdq = new PersistenciaDeQuarto("teste1.txt"); 

  pdq->inserir(q1);
  pdq->inserir(q2); 
  pdq->inserir(q3);
  delete q1;
  delete q2;
  delete q3;
  delete pdq;
}

void teste2() {
}