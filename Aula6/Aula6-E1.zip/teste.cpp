#include "Quarto.h"
#include "Reserva.h"
#include "PacoteDeFinalDeSemana.h"

void teste1() {
    Quarto *q1 =  new Quarto(25,3,2);
    Reserva *r1  = new Reserva(q1,2,4);
    PacoteDeFinalDeSemana *pfds = new PacoteDeFinalDeSemana(q1, 5,true);

    // Funções dadas    
    r1->imprimir();
    pfds->imprimir();
}

void teste2() {

}