void teste1();
void teste2();
void teste3();

int main() {
    teste3();
    return 0;
}