#include "Entrada.h"

Entrada::Entrada(Data*d) : Registro(d){}
Entrada::Entrada(Data * d, bool manual) : Registro(d, manual){}
Entrada::~Entrada(){}
