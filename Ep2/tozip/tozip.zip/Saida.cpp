#include "Saida.h"


Saida::Saida(Data* d) : Registro(d){}
Saida::Saida(Data* d, bool manual) : Registro(d, manual){}
Saida::~Saida(){}