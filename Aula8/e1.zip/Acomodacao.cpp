#include "Acomodacao.h"

Acomodacao::Acomodacao(int numero) {
  this->numero = numero;
}

Acomodacao::~Acomodacao() {
}

int Acomodacao::getNumero() {
  return numero;
}
