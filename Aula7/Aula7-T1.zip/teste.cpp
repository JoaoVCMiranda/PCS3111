#include "QuartoDeLuxo.h"

void teste1() {
    QuartoDeLuxo* ql1 = new QuartoDeLuxo(18, true, false);
    QuartoDeLuxo* ql2 = new QuartoDeLuxo(19, true, true);
    QuartoDeLuxo* ql3 = new QuartoDeLuxo(20, false, true);

    ql1->imprimir();
    ql2->imprimir();
    ql3->imprimir();
}

void teste2() {

}